image
window.onload = function() {
  var SUBMIT = document.querySelector('#contact-me-form');

  SUBMIT.onsubmit = function(event) {
    if(!SUBMIT.checkValidity()) {
    
      SUBMIT.classList.add('validated');
  
      event.preventDefault();
      
      return false;
    }


    
    return true;
  }

}


function do_not_show(){

  if (!document.getElementById("hourly-rate-form").classList.contains("hide"))

  document.getElementById("hourly-rate-form").classList.add("hide");

  if(document.getElementById("hourly-rate").required == true)

  document.getElementById("hourly-rate").required = false;

  document.getElementById("hourly-rate").value = "";

}

function show(){

  if (document.getElementById("hourly-rate-form").classList.contains("hide"))

  document.getElementById("hourly-rate-form").classList.remove("hide");

  if(document.getElementById("hourly-rate").required == false)

  document.getElementById("hourly-rate").required = true;

}



